
import React, { useState } from 'react';
import TiwaskarHomepage from './TiwaskarHomepage.jsx';
import TiwaskarMenu from './TiwaskarMenu.jsx';

export default function App() {
  const [page, setPage] = useState('home');
  return page === 'home' ? <TiwaskarHomepage /> : <TiwaskarMenu />;
}
